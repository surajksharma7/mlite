# mlite/__init__.py

from .regression import linear_regression, multiple_linear_regression

__all__ = ['linear_regression', 'multiple_linear_regression']
